[[Topics/Beta/note#Target Heading|Heading target]]
[[Topics/Beta/note#^block-731|Block target]]
