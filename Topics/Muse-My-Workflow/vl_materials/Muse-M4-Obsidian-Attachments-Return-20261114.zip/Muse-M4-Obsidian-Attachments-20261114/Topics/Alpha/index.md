Embedded: ![[assets/sample.png]]
Direct: [[assets/sample.png]]
