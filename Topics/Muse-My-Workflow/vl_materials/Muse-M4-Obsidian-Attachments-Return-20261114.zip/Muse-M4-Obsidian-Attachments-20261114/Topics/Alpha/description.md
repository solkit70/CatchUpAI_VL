The intended image has a red background and blue square.
