def marker():
    return "SYNTH-CODE-731"
